# Project 4-th hour

## Code can be executed in the main file. Note that each `# %%` is a new cell in jupyter kernel.